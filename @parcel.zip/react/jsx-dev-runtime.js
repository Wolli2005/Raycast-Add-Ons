if (process.env.NODE_ENV === 'production') {
  module.exports = require('./jsx-dev-runtime.production');
} else {
  module.exports = require('./jsx-dev-runtime.development');
}
