if (process.env.NODE_ENV === 'production') {
  module.exports = require('./jsx-runtime.production');
} else {
  module.exports = require('./jsx-runtime.development');
}
