"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../../../node_modules/.pnpm/escape-string-regexp@2.0.0/node_modules/escape-string-regexp/index.js
var require_escape_string_regexp = __commonJS({
  "../../../../node_modules/.pnpm/escape-string-regexp@2.0.0/node_modules/escape-string-regexp/index.js"(exports2, module2) {
    "use strict";
    var matchOperatorsRegex = /[|\\{}()[\]^$+*?.-]/g;
    module2.exports = (string) => {
      if (typeof string !== "string") {
        throw new TypeError("Expected a string");
      }
      return string.replace(matchOperatorsRegex, "\\$&");
    };
  }
});

// ../../../../node_modules/.pnpm/stack-utils@2.0.6/node_modules/stack-utils/index.js
var require_stack_utils = __commonJS({
  "../../../../node_modules/.pnpm/stack-utils@2.0.6/node_modules/stack-utils/index.js"(exports2, module2) {
    "use strict";
    var escapeStringRegexp = require_escape_string_regexp();
    var cwd = typeof process === "object" && process && typeof process.cwd === "function" ? process.cwd() : ".";
    var natives = [].concat(
      require("module").builtinModules,
      "bootstrap_node",
      "node"
    ).map((n) => new RegExp(`(?:\\((?:node:)?${n}(?:\\.js)?:\\d+:\\d+\\)$|^\\s*at (?:node:)?${n}(?:\\.js)?:\\d+:\\d+$)`));
    natives.push(
      /\((?:node:)?internal\/[^:]+:\d+:\d+\)$/,
      /\s*at (?:node:)?internal\/[^:]+:\d+:\d+$/,
      /\/\.node-spawn-wrap-\w+-\w+\/node:\d+:\d+\)?$/
    );
    var StackUtils2 = class _StackUtils {
      constructor(opts) {
        opts = {
          ignoredPackages: [],
          ...opts
        };
        if ("internals" in opts === false) {
          opts.internals = _StackUtils.nodeInternals();
        }
        if ("cwd" in opts === false) {
          opts.cwd = cwd;
        }
        this._cwd = opts.cwd.replace(/\\/g, "/");
        this._internals = [].concat(
          opts.internals,
          ignoredPackagesRegExp(opts.ignoredPackages)
        );
        this._wrapCallSite = opts.wrapCallSite || false;
      }
      static nodeInternals() {
        return [...natives];
      }
      clean(stack, indent = 0) {
        indent = " ".repeat(indent);
        if (!Array.isArray(stack)) {
          stack = stack.split("\n");
        }
        if (!/^\s*at /.test(stack[0]) && /^\s*at /.test(stack[1])) {
          stack = stack.slice(1);
        }
        let outdent = false;
        let lastNonAtLine = null;
        const result = [];
        stack.forEach((st) => {
          st = st.replace(/\\/g, "/");
          if (this._internals.some((internal) => internal.test(st))) {
            return;
          }
          const isAtLine = /^\s*at /.test(st);
          if (outdent) {
            st = st.trimEnd().replace(/^(\s+)at /, "$1");
          } else {
            st = st.trim();
            if (isAtLine) {
              st = st.slice(3);
            }
          }
          st = st.replace(`${this._cwd}/`, "");
          if (st) {
            if (isAtLine) {
              if (lastNonAtLine) {
                result.push(lastNonAtLine);
                lastNonAtLine = null;
              }
              result.push(st);
            } else {
              outdent = true;
              lastNonAtLine = st;
            }
          }
        });
        return result.map((line) => `${indent}${line}
`).join("");
      }
      captureString(limit, fn = this.captureString) {
        if (typeof limit === "function") {
          fn = limit;
          limit = Infinity;
        }
        const { stackTraceLimit } = Error;
        if (limit) {
          Error.stackTraceLimit = limit;
        }
        const obj = {};
        Error.captureStackTrace(obj, fn);
        const { stack } = obj;
        Error.stackTraceLimit = stackTraceLimit;
        return this.clean(stack);
      }
      capture(limit, fn = this.capture) {
        if (typeof limit === "function") {
          fn = limit;
          limit = Infinity;
        }
        const { prepareStackTrace, stackTraceLimit } = Error;
        Error.prepareStackTrace = (obj2, site) => {
          if (this._wrapCallSite) {
            return site.map(this._wrapCallSite);
          }
          return site;
        };
        if (limit) {
          Error.stackTraceLimit = limit;
        }
        const obj = {};
        Error.captureStackTrace(obj, fn);
        const { stack } = obj;
        Object.assign(Error, { prepareStackTrace, stackTraceLimit });
        return stack;
      }
      at(fn = this.at) {
        const [site] = this.capture(1, fn);
        if (!site) {
          return {};
        }
        const res = {
          line: site.getLineNumber(),
          column: site.getColumnNumber()
        };
        setFile(res, site.getFileName(), this._cwd);
        if (site.isConstructor()) {
          Object.defineProperty(res, "constructor", {
            value: true,
            configurable: true
          });
        }
        if (site.isEval()) {
          res.evalOrigin = site.getEvalOrigin();
        }
        if (site.isNative()) {
          res.native = true;
        }
        let typename;
        try {
          typename = site.getTypeName();
        } catch (_) {
        }
        if (typename && typename !== "Object" && typename !== "[object Object]") {
          res.type = typename;
        }
        const fname = site.getFunctionName();
        if (fname) {
          res.function = fname;
        }
        const meth = site.getMethodName();
        if (meth && fname !== meth) {
          res.method = meth;
        }
        return res;
      }
      parseLine(line) {
        const match = line && line.match(re);
        if (!match) {
          return null;
        }
        const ctor = match[1] === "new";
        let fname = match[2];
        const evalOrigin = match[3];
        const evalFile = match[4];
        const evalLine = Number(match[5]);
        const evalCol = Number(match[6]);
        let file = match[7];
        const lnum = match[8];
        const col = match[9];
        const native = match[10] === "native";
        const closeParen = match[11] === ")";
        let method;
        const res = {};
        if (lnum) {
          res.line = Number(lnum);
        }
        if (col) {
          res.column = Number(col);
        }
        if (closeParen && file) {
          let closes = 0;
          for (let i = file.length - 1; i > 0; i--) {
            if (file.charAt(i) === ")") {
              closes++;
            } else if (file.charAt(i) === "(" && file.charAt(i - 1) === " ") {
              closes--;
              if (closes === -1 && file.charAt(i - 1) === " ") {
                const before = file.slice(0, i - 1);
                const after = file.slice(i + 1);
                file = after;
                fname += ` (${before}`;
                break;
              }
            }
          }
        }
        if (fname) {
          const methodMatch = fname.match(methodRe);
          if (methodMatch) {
            fname = methodMatch[1];
            method = methodMatch[2];
          }
        }
        setFile(res, file, this._cwd);
        if (ctor) {
          Object.defineProperty(res, "constructor", {
            value: true,
            configurable: true
          });
        }
        if (evalOrigin) {
          res.evalOrigin = evalOrigin;
          res.evalLine = evalLine;
          res.evalColumn = evalCol;
          res.evalFile = evalFile && evalFile.replace(/\\/g, "/");
        }
        if (native) {
          res.native = true;
        }
        if (fname) {
          res.function = fname;
        }
        if (method && fname !== method) {
          res.method = method;
        }
        return res;
      }
    };
    function setFile(result, filename, cwd2) {
      if (filename) {
        filename = filename.replace(/\\/g, "/");
        if (filename.startsWith(`${cwd2}/`)) {
          filename = filename.slice(cwd2.length + 1);
        }
        result.file = filename;
      }
    }
    function ignoredPackagesRegExp(ignoredPackages) {
      if (ignoredPackages.length === 0) {
        return [];
      }
      const packages = ignoredPackages.map((mod) => escapeStringRegexp(mod));
      return new RegExp(`[/\\\\]node_modules[/\\\\](?:${packages.join("|")})[/\\\\][^:]+:\\d+:\\d+`);
    }
    var re = new RegExp(
      "^(?:\\s*at )?(?:(new) )?(?:(.*?) \\()?(?:eval at ([^ ]+) \\((.+?):(\\d+):(\\d+)\\), )?(?:(.+?):(\\d+):(\\d+)|(native))(\\)?)$"
    );
    var methodRe = /^(.*?) \[as (.*?)\]$/;
    module2.exports = StackUtils2;
  }
});

// src/source-mapper/index.ts
var import_worker_threads = require("worker_threads");

// src/source-mapper/source-mapping.ts
var import_node_fs = __toESM(require("node:fs"));
var import_node_path = __toESM(require("node:path"));
var import_source_map = __toESM(require("@parcel/source-map"));
var sourceMapRegex = /data:application\/json[^,]+base64,/;
var mappingExclusions = [/^node:/];
var maxMappedStackLines = 1;
function sourceMapErrorMessage(message, firstStackItem, sourceMap) {
  const isNotAFunctionRegex = /^(?!\bundefined\b)\b(\w+)\b is not a function$/;
  if (!sourceMap || typeof firstStackItem.line === "undefined" || typeof firstStackItem.column === "undefined" || !isNotAFunctionRegex.test(message)) {
    return message;
  }
  const { line, column } = firstStackItem;
  const match = sourceMap.findClosestMapping(line, column);
  if (!match?.name) {
    return message;
  }
  return message.replace(/^\b(\w+)\b/, match.name);
}
function mapStackItem(stackItem, sourceMap, includeFileContent) {
  if (!stackItem.file || !stackItem.line || !stackItem.column) {
    return stackItem;
  }
  const mapping = sourceMap.findClosestMapping(stackItem.line, stackItem.column);
  if (!mapping) {
    return stackItem;
  }
  return {
    raw: stackItem.raw,
    file: import_node_path.default.resolve(import_node_path.default.dirname(stackItem.file), mapping.source ?? ""),
    fileContent: includeFileContent && mapping.source ? sourceMap.getSourceContent(mapping.source) : void 0,
    line: mapping.original?.line,
    column: mapping.original?.column,
    function: stackItem.function
  };
}
function readExternalSourceMap(file) {
  const sourceMapFile = `${file}.map`;
  if (!import_node_fs.default.existsSync(sourceMapFile)) {
    return null;
  }
  return import_node_fs.default.readFileSync(sourceMapFile).toString("utf8");
}
function readInlineSourceMap(file) {
  if (!import_node_fs.default.existsSync(file)) {
    return null;
  }
  const fileContents = import_node_fs.default.readFileSync(file).toString("utf8");
  if (!sourceMapRegex.test(fileContents)) {
    return null;
  }
  const base64Encoded = fileContents.slice(fileContents.lastIndexOf(",") + 1);
  const base64Decoded = Buffer.from(base64Encoded, "base64").toString("utf8");
  return base64Decoded;
}
function createSourceMap(file) {
  if (mappingExclusions.some((exclusion) => exclusion.test(file))) {
    return null;
  }
  const sourceMapContent = readInlineSourceMap(file) ?? readExternalSourceMap(file);
  if (!sourceMapContent) {
    return null;
  }
  const vlqMap = JSON.parse(sourceMapContent);
  const sourceMap = new import_source_map.default();
  sourceMap.addVLQMap(vlqMap);
  return sourceMap;
}
function performSourceMapping(message, stack, reactComponentStack) {
  if (!stack) {
    return { message, stack, reactComponentStack };
  }
  const sourceMaps = /* @__PURE__ */ new Map();
  let numMappedItems = 0;
  const mappedStack = stack.map((stackItem) => {
    if (numMappedItems >= maxMappedStackLines || !stackItem.file) {
      return stackItem;
    }
    try {
      const sourceMap = sourceMaps.get(stackItem.file) ?? createSourceMap(stackItem.file);
      if (!sourceMap) {
        return stackItem;
      }
      sourceMaps.set(stackItem.file, sourceMap);
      return mapStackItem(stackItem, sourceMap, numMappedItems === 0);
    } catch {
    } finally {
      numMappedItems += 1;
    }
    return stackItem;
  });
  numMappedItems = 0;
  const mappedComponentStack = reactComponentStack?.map((stackItem) => {
    if (numMappedItems >= maxMappedStackLines || !stackItem.file) {
      return stackItem;
    }
    try {
      const sourceMap = sourceMaps.get(stackItem.file) ?? createSourceMap(stackItem.file);
      if (!sourceMap) {
        return stackItem;
      }
      sourceMaps.set(stackItem.file, sourceMap);
      return mapStackItem(stackItem, sourceMap, numMappedItems === 0);
    } catch {
    } finally {
      numMappedItems += 1;
    }
    return stackItem;
  });
  const firstStackItem = stack[0];
  if (!firstStackItem || typeof firstStackItem.file === "undefined" || typeof message === "undefined") {
    return { message, stack: mappedStack, reactComponentStack: mappedComponentStack };
  }
  return {
    message: sourceMapErrorMessage(message, firstStackItem, sourceMaps.get(firstStackItem.file)),
    stack: mappedStack,
    reactComponentStack: mappedComponentStack
  };
}

// src/source-mapper/stacktrace.ts
var import_stack_utils = __toESM(require_stack_utils());
var stackExclusions = [/server\/index.js$/, /^node:internal\/process\/task_queues/];
var maxStackLines = 5;
var stackUtils = new import_stack_utils.default({ internals: import_stack_utils.default.nodeInternals() });
function parseStackTrace(stack) {
  if (!stack) {
    return void 0;
  }
  const stackItems = stack.split("\n").slice(1, maxStackLines).map((line) => {
    const parsedLine = stackUtils.parseLine(line);
    return {
      raw: line,
      file: parsedLine?.file,
      line: parsedLine?.line,
      column: parsedLine?.column,
      function: parsedLine?.function
    };
  });
  return stackItems.filter((stackItem) => {
    return !stackExclusions.some((exclusion) => {
      return exclusion.test(stackItem.file ?? "");
    });
  });
}

// src/source-mapper/index.ts
import_worker_threads.parentPort?.postMessage(
  performSourceMapping(
    import_worker_threads.workerData?.message,
    parseStackTrace(import_worker_threads.workerData?.stack),
    parseStackTrace(import_worker_threads.workerData?.reactComponentStack)
  )
);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2VzY2FwZS1zdHJpbmctcmVnZXhwQDIuMC4wL25vZGVfbW9kdWxlcy9lc2NhcGUtc3RyaW5nLXJlZ2V4cC9pbmRleC5qcyIsICIuLi8uLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3RhY2stdXRpbHNAMi4wLjYvbm9kZV9tb2R1bGVzL3N0YWNrLXV0aWxzL2luZGV4LmpzIiwgIi4uLy4uLy4uL3NyYy9zb3VyY2UtbWFwcGVyL2luZGV4LnRzIiwgIi4uLy4uLy4uL3NyYy9zb3VyY2UtbWFwcGVyL3NvdXJjZS1tYXBwaW5nLnRzIiwgIi4uLy4uLy4uL3NyYy9zb3VyY2UtbWFwcGVyL3N0YWNrdHJhY2UudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIid1c2Ugc3RyaWN0JztcblxuY29uc3QgbWF0Y2hPcGVyYXRvcnNSZWdleCA9IC9bfFxcXFx7fSgpW1xcXV4kKyo/Li1dL2c7XG5cbm1vZHVsZS5leHBvcnRzID0gc3RyaW5nID0+IHtcblx0aWYgKHR5cGVvZiBzdHJpbmcgIT09ICdzdHJpbmcnKSB7XG5cdFx0dGhyb3cgbmV3IFR5cGVFcnJvcignRXhwZWN0ZWQgYSBzdHJpbmcnKTtcblx0fVxuXG5cdHJldHVybiBzdHJpbmcucmVwbGFjZShtYXRjaE9wZXJhdG9yc1JlZ2V4LCAnXFxcXCQmJyk7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxuY29uc3QgZXNjYXBlU3RyaW5nUmVnZXhwID0gcmVxdWlyZSgnZXNjYXBlLXN0cmluZy1yZWdleHAnKTtcblxuY29uc3QgY3dkID0gdHlwZW9mIHByb2Nlc3MgPT09ICdvYmplY3QnICYmIHByb2Nlc3MgJiYgdHlwZW9mIHByb2Nlc3MuY3dkID09PSAnZnVuY3Rpb24nXG4gID8gcHJvY2Vzcy5jd2QoKVxuICA6ICcuJ1xuXG5jb25zdCBuYXRpdmVzID0gW10uY29uY2F0KFxuICByZXF1aXJlKCdtb2R1bGUnKS5idWlsdGluTW9kdWxlcyxcbiAgJ2Jvb3RzdHJhcF9ub2RlJyxcbiAgJ25vZGUnLFxuKS5tYXAobiA9PiBuZXcgUmVnRXhwKGAoPzpcXFxcKCg/Om5vZGU6KT8ke259KD86XFxcXC5qcyk/OlxcXFxkKzpcXFxcZCtcXFxcKSR8XlxcXFxzKmF0ICg/Om5vZGU6KT8ke259KD86XFxcXC5qcyk/OlxcXFxkKzpcXFxcZCskKWApKTtcblxubmF0aXZlcy5wdXNoKFxuICAvXFwoKD86bm9kZTopP2ludGVybmFsXFwvW146XSs6XFxkKzpcXGQrXFwpJC8sXG4gIC9cXHMqYXQgKD86bm9kZTopP2ludGVybmFsXFwvW146XSs6XFxkKzpcXGQrJC8sXG4gIC9cXC9cXC5ub2RlLXNwYXduLXdyYXAtXFx3Ky1cXHcrXFwvbm9kZTpcXGQrOlxcZCtcXCk/JC9cbik7XG5cbmNsYXNzIFN0YWNrVXRpbHMge1xuICBjb25zdHJ1Y3RvciAob3B0cykge1xuICAgIG9wdHMgPSB7XG4gICAgICBpZ25vcmVkUGFja2FnZXM6IFtdLFxuICAgICAgLi4ub3B0c1xuICAgIH07XG5cbiAgICBpZiAoJ2ludGVybmFscycgaW4gb3B0cyA9PT0gZmFsc2UpIHtcbiAgICAgIG9wdHMuaW50ZXJuYWxzID0gU3RhY2tVdGlscy5ub2RlSW50ZXJuYWxzKCk7XG4gICAgfVxuXG4gICAgaWYgKCdjd2QnIGluIG9wdHMgPT09IGZhbHNlKSB7XG4gICAgICBvcHRzLmN3ZCA9IGN3ZFxuICAgIH1cblxuICAgIHRoaXMuX2N3ZCA9IG9wdHMuY3dkLnJlcGxhY2UoL1xcXFwvZywgJy8nKTtcbiAgICB0aGlzLl9pbnRlcm5hbHMgPSBbXS5jb25jYXQoXG4gICAgICBvcHRzLmludGVybmFscyxcbiAgICAgIGlnbm9yZWRQYWNrYWdlc1JlZ0V4cChvcHRzLmlnbm9yZWRQYWNrYWdlcylcbiAgICApO1xuXG4gICAgdGhpcy5fd3JhcENhbGxTaXRlID0gb3B0cy53cmFwQ2FsbFNpdGUgfHwgZmFsc2U7XG4gIH1cblxuICBzdGF0aWMgbm9kZUludGVybmFscyAoKSB7XG4gICAgcmV0dXJuIFsuLi5uYXRpdmVzXTtcbiAgfVxuXG4gIGNsZWFuIChzdGFjaywgaW5kZW50ID0gMCkge1xuICAgIGluZGVudCA9ICcgJy5yZXBlYXQoaW5kZW50KTtcblxuICAgIGlmICghQXJyYXkuaXNBcnJheShzdGFjaykpIHtcbiAgICAgIHN0YWNrID0gc3RhY2suc3BsaXQoJ1xcbicpO1xuICAgIH1cblxuICAgIGlmICghKC9eXFxzKmF0IC8udGVzdChzdGFja1swXSkpICYmICgvXlxccyphdCAvLnRlc3Qoc3RhY2tbMV0pKSkge1xuICAgICAgc3RhY2sgPSBzdGFjay5zbGljZSgxKTtcbiAgICB9XG5cbiAgICBsZXQgb3V0ZGVudCA9IGZhbHNlO1xuICAgIGxldCBsYXN0Tm9uQXRMaW5lID0gbnVsbDtcbiAgICBjb25zdCByZXN1bHQgPSBbXTtcblxuICAgIHN0YWNrLmZvckVhY2goc3QgPT4ge1xuICAgICAgc3QgPSBzdC5yZXBsYWNlKC9cXFxcL2csICcvJyk7XG5cbiAgICAgIGlmICh0aGlzLl9pbnRlcm5hbHMuc29tZShpbnRlcm5hbCA9PiBpbnRlcm5hbC50ZXN0KHN0KSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBpc0F0TGluZSA9IC9eXFxzKmF0IC8udGVzdChzdCk7XG5cbiAgICAgIGlmIChvdXRkZW50KSB7XG4gICAgICAgIHN0ID0gc3QudHJpbUVuZCgpLnJlcGxhY2UoL14oXFxzKylhdCAvLCAnJDEnKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN0ID0gc3QudHJpbSgpO1xuICAgICAgICBpZiAoaXNBdExpbmUpIHtcbiAgICAgICAgICBzdCA9IHN0LnNsaWNlKDMpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHN0ID0gc3QucmVwbGFjZShgJHt0aGlzLl9jd2R9L2AsICcnKTtcblxuICAgICAgaWYgKHN0KSB7XG4gICAgICAgIGlmIChpc0F0TGluZSkge1xuICAgICAgICAgIGlmIChsYXN0Tm9uQXRMaW5lKSB7XG4gICAgICAgICAgICByZXN1bHQucHVzaChsYXN0Tm9uQXRMaW5lKTtcbiAgICAgICAgICAgIGxhc3ROb25BdExpbmUgPSBudWxsO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJlc3VsdC5wdXNoKHN0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvdXRkZW50ID0gdHJ1ZTtcbiAgICAgICAgICBsYXN0Tm9uQXRMaW5lID0gc3Q7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHJldHVybiByZXN1bHQubWFwKGxpbmUgPT4gYCR7aW5kZW50fSR7bGluZX1cXG5gKS5qb2luKCcnKTtcbiAgfVxuXG4gIGNhcHR1cmVTdHJpbmcgKGxpbWl0LCBmbiA9IHRoaXMuY2FwdHVyZVN0cmluZykge1xuICAgIGlmICh0eXBlb2YgbGltaXQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGZuID0gbGltaXQ7XG4gICAgICBsaW1pdCA9IEluZmluaXR5O1xuICAgIH1cblxuICAgIGNvbnN0IHtzdGFja1RyYWNlTGltaXR9ID0gRXJyb3I7XG4gICAgaWYgKGxpbWl0KSB7XG4gICAgICBFcnJvci5zdGFja1RyYWNlTGltaXQgPSBsaW1pdDtcbiAgICB9XG5cbiAgICBjb25zdCBvYmogPSB7fTtcblxuICAgIEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKG9iaiwgZm4pO1xuICAgIGNvbnN0IHtzdGFja30gPSBvYmo7XG4gICAgRXJyb3Iuc3RhY2tUcmFjZUxpbWl0ID0gc3RhY2tUcmFjZUxpbWl0O1xuXG4gICAgcmV0dXJuIHRoaXMuY2xlYW4oc3RhY2spO1xuICB9XG5cbiAgY2FwdHVyZSAobGltaXQsIGZuID0gdGhpcy5jYXB0dXJlKSB7XG4gICAgaWYgKHR5cGVvZiBsaW1pdCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgZm4gPSBsaW1pdDtcbiAgICAgIGxpbWl0ID0gSW5maW5pdHk7XG4gICAgfVxuXG4gICAgY29uc3Qge3ByZXBhcmVTdGFja1RyYWNlLCBzdGFja1RyYWNlTGltaXR9ID0gRXJyb3I7XG4gICAgRXJyb3IucHJlcGFyZVN0YWNrVHJhY2UgPSAob2JqLCBzaXRlKSA9PiB7XG4gICAgICBpZiAodGhpcy5fd3JhcENhbGxTaXRlKSB7XG4gICAgICAgIHJldHVybiBzaXRlLm1hcCh0aGlzLl93cmFwQ2FsbFNpdGUpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gc2l0ZTtcbiAgICB9O1xuXG4gICAgaWYgKGxpbWl0KSB7XG4gICAgICBFcnJvci5zdGFja1RyYWNlTGltaXQgPSBsaW1pdDtcbiAgICB9XG5cbiAgICBjb25zdCBvYmogPSB7fTtcbiAgICBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZShvYmosIGZuKTtcbiAgICBjb25zdCB7IHN0YWNrIH0gPSBvYmo7XG4gICAgT2JqZWN0LmFzc2lnbihFcnJvciwge3ByZXBhcmVTdGFja1RyYWNlLCBzdGFja1RyYWNlTGltaXR9KTtcblxuICAgIHJldHVybiBzdGFjaztcbiAgfVxuXG4gIGF0IChmbiA9IHRoaXMuYXQpIHtcbiAgICBjb25zdCBbc2l0ZV0gPSB0aGlzLmNhcHR1cmUoMSwgZm4pO1xuXG4gICAgaWYgKCFzaXRlKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuXG4gICAgY29uc3QgcmVzID0ge1xuICAgICAgbGluZTogc2l0ZS5nZXRMaW5lTnVtYmVyKCksXG4gICAgICBjb2x1bW46IHNpdGUuZ2V0Q29sdW1uTnVtYmVyKClcbiAgICB9O1xuXG4gICAgc2V0RmlsZShyZXMsIHNpdGUuZ2V0RmlsZU5hbWUoKSwgdGhpcy5fY3dkKTtcblxuICAgIGlmIChzaXRlLmlzQ29uc3RydWN0b3IoKSkge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHJlcywgJ2NvbnN0cnVjdG9yJywge1xuICAgICAgICB2YWx1ZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgaWYgKHNpdGUuaXNFdmFsKCkpIHtcbiAgICAgIHJlcy5ldmFsT3JpZ2luID0gc2l0ZS5nZXRFdmFsT3JpZ2luKCk7XG4gICAgfVxuXG4gICAgLy8gTm9kZSB2MTAgc3RvcHBlZCB3aXRoIHRoZSBpc05hdGl2ZSgpIG9uIGNhbGxzaXRlcywgYXBwYXJlbnRseVxuICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXG4gICAgaWYgKHNpdGUuaXNOYXRpdmUoKSkge1xuICAgICAgcmVzLm5hdGl2ZSA9IHRydWU7XG4gICAgfVxuXG4gICAgbGV0IHR5cGVuYW1lO1xuICAgIHRyeSB7XG4gICAgICB0eXBlbmFtZSA9IHNpdGUuZ2V0VHlwZU5hbWUoKTtcbiAgICB9IGNhdGNoIChfKSB7XG4gICAgfVxuXG4gICAgaWYgKHR5cGVuYW1lICYmIHR5cGVuYW1lICE9PSAnT2JqZWN0JyAmJiB0eXBlbmFtZSAhPT0gJ1tvYmplY3QgT2JqZWN0XScpIHtcbiAgICAgIHJlcy50eXBlID0gdHlwZW5hbWU7XG4gICAgfVxuXG4gICAgY29uc3QgZm5hbWUgPSBzaXRlLmdldEZ1bmN0aW9uTmFtZSgpO1xuICAgIGlmIChmbmFtZSkge1xuICAgICAgcmVzLmZ1bmN0aW9uID0gZm5hbWU7XG4gICAgfVxuXG4gICAgY29uc3QgbWV0aCA9IHNpdGUuZ2V0TWV0aG9kTmFtZSgpO1xuICAgIGlmIChtZXRoICYmIGZuYW1lICE9PSBtZXRoKSB7XG4gICAgICByZXMubWV0aG9kID0gbWV0aDtcbiAgICB9XG5cbiAgICByZXR1cm4gcmVzO1xuICB9XG5cbiAgcGFyc2VMaW5lIChsaW5lKSB7XG4gICAgY29uc3QgbWF0Y2ggPSBsaW5lICYmIGxpbmUubWF0Y2gocmUpO1xuICAgIGlmICghbWF0Y2gpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGNvbnN0IGN0b3IgPSBtYXRjaFsxXSA9PT0gJ25ldyc7XG4gICAgbGV0IGZuYW1lID0gbWF0Y2hbMl07XG4gICAgY29uc3QgZXZhbE9yaWdpbiA9IG1hdGNoWzNdO1xuICAgIGNvbnN0IGV2YWxGaWxlID0gbWF0Y2hbNF07XG4gICAgY29uc3QgZXZhbExpbmUgPSBOdW1iZXIobWF0Y2hbNV0pO1xuICAgIGNvbnN0IGV2YWxDb2wgPSBOdW1iZXIobWF0Y2hbNl0pO1xuICAgIGxldCBmaWxlID0gbWF0Y2hbN107XG4gICAgY29uc3QgbG51bSA9IG1hdGNoWzhdO1xuICAgIGNvbnN0IGNvbCA9IG1hdGNoWzldO1xuICAgIGNvbnN0IG5hdGl2ZSA9IG1hdGNoWzEwXSA9PT0gJ25hdGl2ZSc7XG4gICAgY29uc3QgY2xvc2VQYXJlbiA9IG1hdGNoWzExXSA9PT0gJyknO1xuICAgIGxldCBtZXRob2Q7XG5cbiAgICBjb25zdCByZXMgPSB7fTtcblxuICAgIGlmIChsbnVtKSB7XG4gICAgICByZXMubGluZSA9IE51bWJlcihsbnVtKTtcbiAgICB9XG5cbiAgICBpZiAoY29sKSB7XG4gICAgICByZXMuY29sdW1uID0gTnVtYmVyKGNvbCk7XG4gICAgfVxuXG4gICAgaWYgKGNsb3NlUGFyZW4gJiYgZmlsZSkge1xuICAgICAgLy8gbWFrZSBzdXJlIHBhcmVucyBhcmUgYmFsYW5jZWRcbiAgICAgIC8vIGlmIHdlIGhhdmUgYSBmaWxlIGxpa2UgXCJhc2RmKSBbYXMgZm9vXSAoeHl6LmpzXCIsIHRoZW4gb2RkcyBhcmVcbiAgICAgIC8vIHRoYXQgdGhlIGZuYW1lIHNob3VsZCBiZSArPSBcIiAoYXNkZikgW2FzIGZvb11cIiBhbmQgdGhlIGZpbGVcbiAgICAgIC8vIHNob3VsZCBiZSBqdXN0IFwieHl6LmpzXCJcbiAgICAgIC8vIHdhbGsgYmFja3dhcmRzIGZyb20gdGhlIGVuZCB0byBmaW5kIHRoZSBsYXN0IHVuYmFsYW5jZWQgKFxuICAgICAgbGV0IGNsb3NlcyA9IDA7XG4gICAgICBmb3IgKGxldCBpID0gZmlsZS5sZW5ndGggLSAxOyBpID4gMDsgaS0tKSB7XG4gICAgICAgIGlmIChmaWxlLmNoYXJBdChpKSA9PT0gJyknKSB7XG4gICAgICAgICAgY2xvc2VzKys7XG4gICAgICAgIH0gZWxzZSBpZiAoZmlsZS5jaGFyQXQoaSkgPT09ICcoJyAmJiBmaWxlLmNoYXJBdChpIC0gMSkgPT09ICcgJykge1xuICAgICAgICAgIGNsb3Nlcy0tO1xuICAgICAgICAgIGlmIChjbG9zZXMgPT09IC0xICYmIGZpbGUuY2hhckF0KGkgLSAxKSA9PT0gJyAnKSB7XG4gICAgICAgICAgICBjb25zdCBiZWZvcmUgPSBmaWxlLnNsaWNlKDAsIGkgLSAxKTtcbiAgICAgICAgICAgIGNvbnN0IGFmdGVyID0gZmlsZS5zbGljZShpICsgMSk7XG4gICAgICAgICAgICBmaWxlID0gYWZ0ZXI7XG4gICAgICAgICAgICBmbmFtZSArPSBgICgke2JlZm9yZX1gO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGZuYW1lKSB7XG4gICAgICBjb25zdCBtZXRob2RNYXRjaCA9IGZuYW1lLm1hdGNoKG1ldGhvZFJlKTtcbiAgICAgIGlmIChtZXRob2RNYXRjaCkge1xuICAgICAgICBmbmFtZSA9IG1ldGhvZE1hdGNoWzFdO1xuICAgICAgICBtZXRob2QgPSBtZXRob2RNYXRjaFsyXTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBzZXRGaWxlKHJlcywgZmlsZSwgdGhpcy5fY3dkKTtcblxuICAgIGlmIChjdG9yKSB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkocmVzLCAnY29uc3RydWN0b3InLCB7XG4gICAgICAgIHZhbHVlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBpZiAoZXZhbE9yaWdpbikge1xuICAgICAgcmVzLmV2YWxPcmlnaW4gPSBldmFsT3JpZ2luO1xuICAgICAgcmVzLmV2YWxMaW5lID0gZXZhbExpbmU7XG4gICAgICByZXMuZXZhbENvbHVtbiA9IGV2YWxDb2w7XG4gICAgICByZXMuZXZhbEZpbGUgPSBldmFsRmlsZSAmJiBldmFsRmlsZS5yZXBsYWNlKC9cXFxcL2csICcvJyk7XG4gICAgfVxuXG4gICAgaWYgKG5hdGl2ZSkge1xuICAgICAgcmVzLm5hdGl2ZSA9IHRydWU7XG4gICAgfVxuXG4gICAgaWYgKGZuYW1lKSB7XG4gICAgICByZXMuZnVuY3Rpb24gPSBmbmFtZTtcbiAgICB9XG5cbiAgICBpZiAobWV0aG9kICYmIGZuYW1lICE9PSBtZXRob2QpIHtcbiAgICAgIHJlcy5tZXRob2QgPSBtZXRob2Q7XG4gICAgfVxuXG4gICAgcmV0dXJuIHJlcztcbiAgfVxufVxuXG5mdW5jdGlvbiBzZXRGaWxlIChyZXN1bHQsIGZpbGVuYW1lLCBjd2QpIHtcbiAgaWYgKGZpbGVuYW1lKSB7XG4gICAgZmlsZW5hbWUgPSBmaWxlbmFtZS5yZXBsYWNlKC9cXFxcL2csICcvJyk7XG4gICAgaWYgKGZpbGVuYW1lLnN0YXJ0c1dpdGgoYCR7Y3dkfS9gKSkge1xuICAgICAgZmlsZW5hbWUgPSBmaWxlbmFtZS5zbGljZShjd2QubGVuZ3RoICsgMSk7XG4gICAgfVxuXG4gICAgcmVzdWx0LmZpbGUgPSBmaWxlbmFtZTtcbiAgfVxufVxuXG5mdW5jdGlvbiBpZ25vcmVkUGFja2FnZXNSZWdFeHAoaWdub3JlZFBhY2thZ2VzKSB7XG4gIGlmIChpZ25vcmVkUGFja2FnZXMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG5cbiAgY29uc3QgcGFja2FnZXMgPSBpZ25vcmVkUGFja2FnZXMubWFwKG1vZCA9PiBlc2NhcGVTdHJpbmdSZWdleHAobW9kKSk7XG5cbiAgcmV0dXJuIG5ldyBSZWdFeHAoYFtcXC9cXFxcXFxcXF1ub2RlX21vZHVsZXNbXFwvXFxcXFxcXFxdKD86JHtwYWNrYWdlcy5qb2luKCd8Jyl9KVtcXC9cXFxcXFxcXF1bXjpdKzpcXFxcZCs6XFxcXGQrYClcbn1cblxuY29uc3QgcmUgPSBuZXcgUmVnRXhwKFxuICAnXicgK1xuICAgIC8vIFNvbWV0aW1lcyB3ZSBzdHJpcCBvdXQgdGhlICcgICAgYXQnIGJlY2F1c2UgaXQncyBub2lzeVxuICAnKD86XFxcXHMqYXQgKT8nICtcbiAgICAvLyAkMSA9IGN0b3IgaWYgJ25ldydcbiAgJyg/OihuZXcpICk/JyArXG4gICAgLy8gJDIgPSBmdW5jdGlvbiBuYW1lIChjYW4gYmUgbGl0ZXJhbGx5IGFueXRoaW5nKVxuICAgIC8vIE1heSBjb250YWluIG1ldGhvZCBhdCB0aGUgZW5kIGFzIFthcyB4eXpdXG4gICcoPzooLio/KSBcXFxcKCk/JyArXG4gICAgLy8gKGV2YWwgYXQgPGFub255bW91cz4gKGZpbGUuanM6MToxKSxcbiAgICAvLyAkMyA9IGV2YWwgb3JpZ2luXG4gICAgLy8gJDQ6JDU6JDYgYXJlIGV2YWwgZmlsZS9saW5lL2NvbCwgYnV0IG5vdCBub3JtYWxseSByZXBvcnRlZFxuICAnKD86ZXZhbCBhdCAoW14gXSspIFxcXFwoKC4rPyk6KFxcXFxkKyk6KFxcXFxkKylcXFxcKSwgKT8nICtcbiAgICAvLyBmaWxlOmxpbmU6Y29sXG4gICAgLy8gJDc6JDg6JDlcbiAgICAvLyAkMTAgPSAnbmF0aXZlJyBpZiBuYXRpdmVcbiAgJyg/OiguKz8pOihcXFxcZCspOihcXFxcZCspfChuYXRpdmUpKScgK1xuICAgIC8vIG1heWJlIGNsb3NlIHRoZSBwYXJlbiwgdGhlbiBlbmRcbiAgICAvLyBpZiAkMTEgaXMgKSwgdGhlbiB3ZSBvbmx5IGFsbG93IGJhbGFuY2VkIHBhcmVucyBpbiB0aGUgZmlsZW5hbWVcbiAgICAvLyBhbnkgaW1iYWxhbmNlIGlzIHBsYWNlZCBvbiB0aGUgZm5hbWUuICBUaGlzIGlzIGEgaGV1cmlzdGljLCBhbmRcbiAgICAvLyBib3VuZCB0byBiZSBpbmNvcnJlY3QgaW4gc29tZSBlZGdlIGNhc2VzLiAgVGhlIGJldCBpcyB0aGF0XG4gICAgLy8gaGF2aW5nIHdlaXJkIGNoYXJhY3RlcnMgaW4gbWV0aG9kIG5hbWVzIGlzIG1vcmUgY29tbW9uIHRoYW5cbiAgICAvLyBoYXZpbmcgd2VpcmQgY2hhcmFjdGVycyBpbiBmaWxlbmFtZXMsIHdoaWNoIHNlZW1zIHJlYXNvbmFibGUuXG4gICcoXFxcXCk/KSQnXG4pO1xuXG5jb25zdCBtZXRob2RSZSA9IC9eKC4qPykgXFxbYXMgKC4qPylcXF0kLztcblxubW9kdWxlLmV4cG9ydHMgPSBTdGFja1V0aWxzO1xuIiwgImltcG9ydCB7IHdvcmtlckRhdGEsIHBhcmVudFBvcnQgfSBmcm9tIFwid29ya2VyX3RocmVhZHNcIjtcclxuaW1wb3J0IHsgcGVyZm9ybVNvdXJjZU1hcHBpbmcgfSBmcm9tIFwiLi9zb3VyY2UtbWFwcGluZ1wiO1xyXG5pbXBvcnQgeyBwYXJzZVN0YWNrVHJhY2UgfSBmcm9tIFwiLi9zdGFja3RyYWNlXCI7XHJcblxyXG5wYXJlbnRQb3J0Py5wb3N0TWVzc2FnZShcclxuICBwZXJmb3JtU291cmNlTWFwcGluZyhcclxuICAgIHdvcmtlckRhdGE/Lm1lc3NhZ2UsXHJcbiAgICBwYXJzZVN0YWNrVHJhY2Uod29ya2VyRGF0YT8uc3RhY2spLFxyXG4gICAgcGFyc2VTdGFja1RyYWNlKHdvcmtlckRhdGE/LnJlYWN0Q29tcG9uZW50U3RhY2spLFxyXG4gICksXHJcbik7XHJcbiIsICJpbXBvcnQgZnMgZnJvbSBcIm5vZGU6ZnNcIjtcclxuaW1wb3J0IHBhdGggZnJvbSBcIm5vZGU6cGF0aFwiO1xyXG5cclxuaW1wb3J0IFNvdXJjZU1hcCBmcm9tIFwiQHBhcmNlbC9zb3VyY2UtbWFwXCI7XHJcblxyXG5pbXBvcnQgeyB0eXBlIFN0YWNrSXRlbSB9IGZyb20gXCIuL3N0YWNrdHJhY2VcIjtcclxuXHJcbi8vIFJlZ2V4IHBhdHRlcm4gZm9yIGlubGluZWQgc291cmNlIG1hcHNcclxuY29uc3Qgc291cmNlTWFwUmVnZXggPSAvZGF0YTphcHBsaWNhdGlvblxcL2pzb25bXixdK2Jhc2U2NCwvO1xyXG4vLyBSZWdleCBwYXR0ZXJucyBmb3IgZmlsZXMgdG8gZXhjbHVkZSBmcm9tIHNvdXJjZSBtYXBwaW5nXHJcbmNvbnN0IG1hcHBpbmdFeGNsdXNpb25zID0gWy9ebm9kZTovXTtcclxuLy8gTWF4aW11bSBudW1iZXIgb2Ygc291cmNlIG1hcHBlZCBzdGFjayBsaW5lc1xyXG4vLyBXZSBsaW1pdCB0aGlzIHRvIDEgc2luY2Ugc3luYyBsb2FkaW5nIG9mIHRvbyBtYW55IHNvdXJjZSBmaWxlcyBjYW4gY2F1c2UgcGVyZm9ybWFuY2UgaXNzdWVzLlxyXG5jb25zdCBtYXhNYXBwZWRTdGFja0xpbmVzID0gMTtcclxuXHJcbi8vIFRha2VzIHRoZSBlcnJvciBvYmplY3QncyBgbWVzc2FnZWAgYW5kLCBmb3IgXCI8eD4gaXMgbm90IGEgZnVuY3Rpb25cIiBgVHlwZUVycm9yYHMsIHRyaWVzIHRvIHJlcGxhY2UgPHg+XHJcbi8vIHdpdGggdGhlIG9yaWdpbmFsIGZ1bmN0aW9uIG5hbWUuXHJcbmZ1bmN0aW9uIHNvdXJjZU1hcEVycm9yTWVzc2FnZShtZXNzYWdlOiBzdHJpbmcsIGZpcnN0U3RhY2tJdGVtOiBTdGFja0l0ZW0sIHNvdXJjZU1hcD86IFNvdXJjZU1hcCk6IHN0cmluZyB7XHJcbiAgY29uc3QgaXNOb3RBRnVuY3Rpb25SZWdleCA9IC9eKD8hXFxidW5kZWZpbmVkXFxiKVxcYihcXHcrKVxcYiBpcyBub3QgYSBmdW5jdGlvbiQvO1xyXG4gIGlmIChcclxuICAgICFzb3VyY2VNYXAgfHxcclxuICAgIHR5cGVvZiBmaXJzdFN0YWNrSXRlbS5saW5lID09PSBcInVuZGVmaW5lZFwiIHx8XHJcbiAgICB0eXBlb2YgZmlyc3RTdGFja0l0ZW0uY29sdW1uID09PSBcInVuZGVmaW5lZFwiIHx8XHJcbiAgICAhaXNOb3RBRnVuY3Rpb25SZWdleC50ZXN0KG1lc3NhZ2UpXHJcbiAgKSB7XHJcbiAgICByZXR1cm4gbWVzc2FnZTtcclxuICB9XHJcbiAgY29uc3QgeyBsaW5lLCBjb2x1bW4gfSA9IGZpcnN0U3RhY2tJdGVtO1xyXG4gIGNvbnN0IG1hdGNoID0gc291cmNlTWFwLmZpbmRDbG9zZXN0TWFwcGluZyhsaW5lLCBjb2x1bW4pO1xyXG4gIGlmICghbWF0Y2g/Lm5hbWUpIHtcclxuICAgIHJldHVybiBtZXNzYWdlO1xyXG4gIH1cclxuICByZXR1cm4gbWVzc2FnZS5yZXBsYWNlKC9eXFxiKFxcdyspXFxiLywgbWF0Y2gubmFtZSk7XHJcbn1cclxuXHJcbi8vIFN0YWNrIFRyYWNlIFByZXBhcmF0aW9uXHJcblxyXG4vLyBTb3VyY2UgTWFwcGluZ1xyXG5mdW5jdGlvbiBtYXBTdGFja0l0ZW0oc3RhY2tJdGVtOiBTdGFja0l0ZW0sIHNvdXJjZU1hcDogU291cmNlTWFwLCBpbmNsdWRlRmlsZUNvbnRlbnQ6IGJvb2xlYW4pOiBTdGFja0l0ZW0ge1xyXG4gIGlmICghc3RhY2tJdGVtLmZpbGUgfHwgIXN0YWNrSXRlbS5saW5lIHx8ICFzdGFja0l0ZW0uY29sdW1uKSB7XHJcbiAgICByZXR1cm4gc3RhY2tJdGVtO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgbWFwcGluZyA9IHNvdXJjZU1hcC5maW5kQ2xvc2VzdE1hcHBpbmcoc3RhY2tJdGVtLmxpbmUsIHN0YWNrSXRlbS5jb2x1bW4pO1xyXG4gIGlmICghbWFwcGluZykge1xyXG4gICAgcmV0dXJuIHN0YWNrSXRlbTtcclxuICB9XHJcbiAgcmV0dXJuIHtcclxuICAgIHJhdzogc3RhY2tJdGVtLnJhdyxcclxuICAgIGZpbGU6IHBhdGgucmVzb2x2ZShwYXRoLmRpcm5hbWUoc3RhY2tJdGVtLmZpbGUpLCBtYXBwaW5nLnNvdXJjZSA/PyBcIlwiKSxcclxuICAgIGZpbGVDb250ZW50OiBpbmNsdWRlRmlsZUNvbnRlbnQgJiYgbWFwcGluZy5zb3VyY2UgPyBzb3VyY2VNYXAuZ2V0U291cmNlQ29udGVudChtYXBwaW5nLnNvdXJjZSkgOiB1bmRlZmluZWQsXHJcbiAgICBsaW5lOiBtYXBwaW5nLm9yaWdpbmFsPy5saW5lLFxyXG4gICAgY29sdW1uOiBtYXBwaW5nLm9yaWdpbmFsPy5jb2x1bW4sXHJcbiAgICBmdW5jdGlvbjogc3RhY2tJdGVtLmZ1bmN0aW9uLFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlYWRFeHRlcm5hbFNvdXJjZU1hcChmaWxlOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICBjb25zdCBzb3VyY2VNYXBGaWxlID0gYCR7ZmlsZX0ubWFwYDtcclxuICBpZiAoIWZzLmV4aXN0c1N5bmMoc291cmNlTWFwRmlsZSkpIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuICByZXR1cm4gZnMucmVhZEZpbGVTeW5jKHNvdXJjZU1hcEZpbGUpLnRvU3RyaW5nKFwidXRmOFwiKTtcclxufVxyXG5cclxuZnVuY3Rpb24gcmVhZElubGluZVNvdXJjZU1hcChmaWxlOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAoIWZzLmV4aXN0c1N5bmMoZmlsZSkpIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuICBjb25zdCBmaWxlQ29udGVudHMgPSBmcy5yZWFkRmlsZVN5bmMoZmlsZSkudG9TdHJpbmcoXCJ1dGY4XCIpO1xyXG4gIGlmICghc291cmNlTWFwUmVnZXgudGVzdChmaWxlQ29udGVudHMpKSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbiAgY29uc3QgYmFzZTY0RW5jb2RlZCA9IGZpbGVDb250ZW50cy5zbGljZShmaWxlQ29udGVudHMubGFzdEluZGV4T2YoXCIsXCIpICsgMSk7XHJcbiAgY29uc3QgYmFzZTY0RGVjb2RlZCA9IEJ1ZmZlci5mcm9tKGJhc2U2NEVuY29kZWQsIFwiYmFzZTY0XCIpLnRvU3RyaW5nKFwidXRmOFwiKTtcclxuICByZXR1cm4gYmFzZTY0RGVjb2RlZDtcclxufVxyXG5cclxuLy8gQXR0ZW1wdHMgdG8gcmVhZCB0aGUgaW5saW5lIHNvdXJjZSBtYXBzIGlmIHByZXNlbnQsIG9yIGV4dGVybmFsIHNvdXJjZSBtYXAgZmlsZSBpZiBub3QuXHJcbmZ1bmN0aW9uIGNyZWF0ZVNvdXJjZU1hcChmaWxlOiBzdHJpbmcpOiBTb3VyY2VNYXAgfCBudWxsIHtcclxuICBpZiAobWFwcGluZ0V4Y2x1c2lvbnMuc29tZSgoZXhjbHVzaW9uKSA9PiBleGNsdXNpb24udGVzdChmaWxlKSkpIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuXHJcbiAgY29uc3Qgc291cmNlTWFwQ29udGVudCA9IHJlYWRJbmxpbmVTb3VyY2VNYXAoZmlsZSkgPz8gcmVhZEV4dGVybmFsU291cmNlTWFwKGZpbGUpO1xyXG5cclxuICBpZiAoIXNvdXJjZU1hcENvbnRlbnQpIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdmxxTWFwID0gSlNPTi5wYXJzZShzb3VyY2VNYXBDb250ZW50KTtcclxuXHJcbiAgY29uc3Qgc291cmNlTWFwID0gbmV3IFNvdXJjZU1hcCgpO1xyXG4gIHNvdXJjZU1hcC5hZGRWTFFNYXAodmxxTWFwKTtcclxuICByZXR1cm4gc291cmNlTWFwO1xyXG59XHJcblxyXG4vLyBFeHBvcnRzXHJcbmV4cG9ydCBmdW5jdGlvbiBwZXJmb3JtU291cmNlTWFwcGluZyhcclxuICBtZXNzYWdlPzogc3RyaW5nLFxyXG4gIHN0YWNrPzogQXJyYXk8U3RhY2tJdGVtPixcclxuICByZWFjdENvbXBvbmVudFN0YWNrPzogQXJyYXk8U3RhY2tJdGVtPixcclxuKTogeyBtZXNzYWdlPzogc3RyaW5nOyBzdGFjaz86IEFycmF5PFN0YWNrSXRlbT47IHJlYWN0Q29tcG9uZW50U3RhY2s/OiBBcnJheTxTdGFja0l0ZW0+IH0ge1xyXG4gIGlmICghc3RhY2spIHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2UsIHN0YWNrLCByZWFjdENvbXBvbmVudFN0YWNrIH07XHJcbiAgfVxyXG4gIGNvbnN0IHNvdXJjZU1hcHMgPSBuZXcgTWFwPHN0cmluZywgU291cmNlTWFwPigpO1xyXG4gIGxldCBudW1NYXBwZWRJdGVtcyA9IDA7XHJcblxyXG4gIGNvbnN0IG1hcHBlZFN0YWNrID0gc3RhY2subWFwKChzdGFja0l0ZW0pID0+IHtcclxuICAgIGlmIChudW1NYXBwZWRJdGVtcyA+PSBtYXhNYXBwZWRTdGFja0xpbmVzIHx8ICFzdGFja0l0ZW0uZmlsZSkge1xyXG4gICAgICByZXR1cm4gc3RhY2tJdGVtO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHNvdXJjZU1hcCA9IHNvdXJjZU1hcHMuZ2V0KHN0YWNrSXRlbS5maWxlKSA/PyBjcmVhdGVTb3VyY2VNYXAoc3RhY2tJdGVtLmZpbGUpO1xyXG4gICAgICBpZiAoIXNvdXJjZU1hcCkge1xyXG4gICAgICAgIHJldHVybiBzdGFja0l0ZW07XHJcbiAgICAgIH1cclxuICAgICAgc291cmNlTWFwcy5zZXQoc3RhY2tJdGVtLmZpbGUsIHNvdXJjZU1hcCk7XHJcbiAgICAgIHJldHVybiBtYXBTdGFja0l0ZW0oc3RhY2tJdGVtLCBzb3VyY2VNYXAsIG51bU1hcHBlZEl0ZW1zID09PSAwKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBpZ25vcmVcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIG51bU1hcHBlZEl0ZW1zICs9IDE7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gc3RhY2tJdGVtO1xyXG4gIH0pO1xyXG5cclxuICBudW1NYXBwZWRJdGVtcyA9IDA7XHJcblxyXG4gIGNvbnN0IG1hcHBlZENvbXBvbmVudFN0YWNrID0gcmVhY3RDb21wb25lbnRTdGFjaz8ubWFwKChzdGFja0l0ZW0pID0+IHtcclxuICAgIGlmIChudW1NYXBwZWRJdGVtcyA+PSBtYXhNYXBwZWRTdGFja0xpbmVzIHx8ICFzdGFja0l0ZW0uZmlsZSkge1xyXG4gICAgICByZXR1cm4gc3RhY2tJdGVtO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHNvdXJjZU1hcCA9IHNvdXJjZU1hcHMuZ2V0KHN0YWNrSXRlbS5maWxlKSA/PyBjcmVhdGVTb3VyY2VNYXAoc3RhY2tJdGVtLmZpbGUpO1xyXG4gICAgICBpZiAoIXNvdXJjZU1hcCkge1xyXG4gICAgICAgIHJldHVybiBzdGFja0l0ZW07XHJcbiAgICAgIH1cclxuICAgICAgc291cmNlTWFwcy5zZXQoc3RhY2tJdGVtLmZpbGUsIHNvdXJjZU1hcCk7XHJcbiAgICAgIHJldHVybiBtYXBTdGFja0l0ZW0oc3RhY2tJdGVtLCBzb3VyY2VNYXAsIG51bU1hcHBlZEl0ZW1zID09PSAwKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBpZ25vcmVcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIG51bU1hcHBlZEl0ZW1zICs9IDE7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gc3RhY2tJdGVtO1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBmaXJzdFN0YWNrSXRlbSA9IHN0YWNrWzBdO1xyXG4gIGlmICghZmlyc3RTdGFja0l0ZW0gfHwgdHlwZW9mIGZpcnN0U3RhY2tJdGVtLmZpbGUgPT09IFwidW5kZWZpbmVkXCIgfHwgdHlwZW9mIG1lc3NhZ2UgPT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2UsIHN0YWNrOiBtYXBwZWRTdGFjaywgcmVhY3RDb21wb25lbnRTdGFjazogbWFwcGVkQ29tcG9uZW50U3RhY2sgfTtcclxuICB9XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBtZXNzYWdlOiBzb3VyY2VNYXBFcnJvck1lc3NhZ2UobWVzc2FnZSwgZmlyc3RTdGFja0l0ZW0sIHNvdXJjZU1hcHMuZ2V0KGZpcnN0U3RhY2tJdGVtLmZpbGUpKSxcclxuICAgIHN0YWNrOiBtYXBwZWRTdGFjayxcclxuICAgIHJlYWN0Q29tcG9uZW50U3RhY2s6IG1hcHBlZENvbXBvbmVudFN0YWNrLFxyXG4gIH07XHJcbn1cclxuIiwgImltcG9ydCBTdGFja1V0aWxzIGZyb20gXCJzdGFjay11dGlsc1wiO1xyXG5cclxuLy8gUmVnZXggcGF0dGVybnMgZm9yIGZpbGVzIHRvIGV4Y2x1ZGUgZnJvbSB0aGUgc3RhY2sgdHJhY2VcclxuY29uc3Qgc3RhY2tFeGNsdXNpb25zID0gWy9zZXJ2ZXJcXC9pbmRleC5qcyQvLCAvXm5vZGU6aW50ZXJuYWxcXC9wcm9jZXNzXFwvdGFza19xdWV1ZXMvXTtcclxuLy8gTWF4aW11bSBudW1iZXIgb2Ygc3RhY2sgbGluZXMgdG8gcHJvY2Vzc1xyXG5jb25zdCBtYXhTdGFja0xpbmVzID0gNTtcclxuXHJcbi8vIFV0aWxpdGllcyBmb3IgcGFyc2luZyBzdGFjayB0cmFjZXMgZnJvbSBlcnJvciBzdGFjayBzdHJpbmdzXHJcbmNvbnN0IHN0YWNrVXRpbHMgPSBuZXcgU3RhY2tVdGlscyh7IGludGVybmFsczogU3RhY2tVdGlscy5ub2RlSW50ZXJuYWxzKCkgfSk7XHJcblxyXG4vLyBQYXJzZXMgdGhlIGdpdmVuIGVycm9yIHN0YWNrIGludG8gc3RydWN0dXJlZCBzdGFjayBpdGVtcy5cclxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU3RhY2tUcmFjZShzdGFjaz86IHN0cmluZyk6IFN0YWNrSXRlbVtdIHwgdW5kZWZpbmVkIHtcclxuICBpZiAoIXN0YWNrKSB7XHJcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gIH1cclxuXHJcbiAgY29uc3Qgc3RhY2tJdGVtcyA9IHN0YWNrXHJcbiAgICAuc3BsaXQoXCJcXG5cIilcclxuICAgIC5zbGljZSgxLCBtYXhTdGFja0xpbmVzKVxyXG4gICAgLm1hcCgobGluZSkgPT4ge1xyXG4gICAgICBjb25zdCBwYXJzZWRMaW5lID0gc3RhY2tVdGlscy5wYXJzZUxpbmUobGluZSk7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgcmF3OiBsaW5lLFxyXG4gICAgICAgIGZpbGU6IHBhcnNlZExpbmU/LmZpbGUsXHJcbiAgICAgICAgbGluZTogcGFyc2VkTGluZT8ubGluZSxcclxuICAgICAgICBjb2x1bW46IHBhcnNlZExpbmU/LmNvbHVtbixcclxuICAgICAgICBmdW5jdGlvbjogcGFyc2VkTGluZT8uZnVuY3Rpb24sXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuXHJcbiAgcmV0dXJuIHN0YWNrSXRlbXMuZmlsdGVyKChzdGFja0l0ZW0pID0+IHtcclxuICAgIHJldHVybiAhc3RhY2tFeGNsdXNpb25zLnNvbWUoKGV4Y2x1c2lvbikgPT4ge1xyXG4gICAgICByZXR1cm4gZXhjbHVzaW9uLnRlc3Qoc3RhY2tJdGVtLmZpbGUgPz8gXCJcIik7XHJcbiAgICB9KTtcclxuICB9KTtcclxufVxyXG5cclxuLy8gVHlwZXNcclxuZXhwb3J0IHR5cGUgU3RhY2tJdGVtID0ge1xyXG4gIHJhdzogc3RyaW5nO1xyXG4gIGZpbGU/OiBzdHJpbmc7XHJcbiAgbGluZT86IG51bWJlcjtcclxuICBjb2x1bW4/OiBudW1iZXI7XHJcbiAgZnVuY3Rpb24/OiBzdHJpbmc7XHJcbiAgZmlsZUNvbnRlbnQ/OiBzdHJpbmc7XHJcbn07XHJcbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUFBLHlHQUFBQSxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLHNCQUFzQjtBQUU1QixJQUFBQSxRQUFPLFVBQVUsWUFBVTtBQUMxQixVQUFJLE9BQU8sV0FBVyxVQUFVO0FBQy9CLGNBQU0sSUFBSSxVQUFVLG1CQUFtQjtBQUFBLE1BQ3hDO0FBRUEsYUFBTyxPQUFPLFFBQVEscUJBQXFCLE1BQU07QUFBQSxJQUNsRDtBQUFBO0FBQUE7OztBQ1ZBO0FBQUEsdUZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0scUJBQXFCO0FBRTNCLFFBQU0sTUFBTSxPQUFPLFlBQVksWUFBWSxXQUFXLE9BQU8sUUFBUSxRQUFRLGFBQ3pFLFFBQVEsSUFBSSxJQUNaO0FBRUosUUFBTSxVQUFVLENBQUMsRUFBRTtBQUFBLE1BQ2pCLFFBQVEsUUFBUSxFQUFFO0FBQUEsTUFDbEI7QUFBQSxNQUNBO0FBQUEsSUFDRixFQUFFLElBQUksT0FBSyxJQUFJLE9BQU8sbUJBQW1CLENBQUMsOENBQThDLENBQUMsd0JBQXdCLENBQUM7QUFFbEgsWUFBUTtBQUFBLE1BQ047QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFFQSxRQUFNQyxjQUFOLE1BQU0sWUFBVztBQUFBLE1BQ2YsWUFBYSxNQUFNO0FBQ2pCLGVBQU87QUFBQSxVQUNMLGlCQUFpQixDQUFDO0FBQUEsVUFDbEIsR0FBRztBQUFBLFFBQ0w7QUFFQSxZQUFJLGVBQWUsU0FBUyxPQUFPO0FBQ2pDLGVBQUssWUFBWSxZQUFXLGNBQWM7QUFBQSxRQUM1QztBQUVBLFlBQUksU0FBUyxTQUFTLE9BQU87QUFDM0IsZUFBSyxNQUFNO0FBQUEsUUFDYjtBQUVBLGFBQUssT0FBTyxLQUFLLElBQUksUUFBUSxPQUFPLEdBQUc7QUFDdkMsYUFBSyxhQUFhLENBQUMsRUFBRTtBQUFBLFVBQ25CLEtBQUs7QUFBQSxVQUNMLHNCQUFzQixLQUFLLGVBQWU7QUFBQSxRQUM1QztBQUVBLGFBQUssZ0JBQWdCLEtBQUssZ0JBQWdCO0FBQUEsTUFDNUM7QUFBQSxNQUVBLE9BQU8sZ0JBQWlCO0FBQ3RCLGVBQU8sQ0FBQyxHQUFHLE9BQU87QUFBQSxNQUNwQjtBQUFBLE1BRUEsTUFBTyxPQUFPLFNBQVMsR0FBRztBQUN4QixpQkFBUyxJQUFJLE9BQU8sTUFBTTtBQUUxQixZQUFJLENBQUMsTUFBTSxRQUFRLEtBQUssR0FBRztBQUN6QixrQkFBUSxNQUFNLE1BQU0sSUFBSTtBQUFBLFFBQzFCO0FBRUEsWUFBSSxDQUFFLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFPLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQyxHQUFJO0FBQzdELGtCQUFRLE1BQU0sTUFBTSxDQUFDO0FBQUEsUUFDdkI7QUFFQSxZQUFJLFVBQVU7QUFDZCxZQUFJLGdCQUFnQjtBQUNwQixjQUFNLFNBQVMsQ0FBQztBQUVoQixjQUFNLFFBQVEsUUFBTTtBQUNsQixlQUFLLEdBQUcsUUFBUSxPQUFPLEdBQUc7QUFFMUIsY0FBSSxLQUFLLFdBQVcsS0FBSyxjQUFZLFNBQVMsS0FBSyxFQUFFLENBQUMsR0FBRztBQUN2RDtBQUFBLFVBQ0Y7QUFFQSxnQkFBTSxXQUFXLFVBQVUsS0FBSyxFQUFFO0FBRWxDLGNBQUksU0FBUztBQUNYLGlCQUFLLEdBQUcsUUFBUSxFQUFFLFFBQVEsYUFBYSxJQUFJO0FBQUEsVUFDN0MsT0FBTztBQUNMLGlCQUFLLEdBQUcsS0FBSztBQUNiLGdCQUFJLFVBQVU7QUFDWixtQkFBSyxHQUFHLE1BQU0sQ0FBQztBQUFBLFlBQ2pCO0FBQUEsVUFDRjtBQUVBLGVBQUssR0FBRyxRQUFRLEdBQUcsS0FBSyxJQUFJLEtBQUssRUFBRTtBQUVuQyxjQUFJLElBQUk7QUFDTixnQkFBSSxVQUFVO0FBQ1osa0JBQUksZUFBZTtBQUNqQix1QkFBTyxLQUFLLGFBQWE7QUFDekIsZ0NBQWdCO0FBQUEsY0FDbEI7QUFFQSxxQkFBTyxLQUFLLEVBQUU7QUFBQSxZQUNoQixPQUFPO0FBQ0wsd0JBQVU7QUFDViw4QkFBZ0I7QUFBQSxZQUNsQjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLENBQUM7QUFFRCxlQUFPLE9BQU8sSUFBSSxVQUFRLEdBQUcsTUFBTSxHQUFHLElBQUk7QUFBQSxDQUFJLEVBQUUsS0FBSyxFQUFFO0FBQUEsTUFDekQ7QUFBQSxNQUVBLGNBQWUsT0FBTyxLQUFLLEtBQUssZUFBZTtBQUM3QyxZQUFJLE9BQU8sVUFBVSxZQUFZO0FBQy9CLGVBQUs7QUFDTCxrQkFBUTtBQUFBLFFBQ1Y7QUFFQSxjQUFNLEVBQUMsZ0JBQWUsSUFBSTtBQUMxQixZQUFJLE9BQU87QUFDVCxnQkFBTSxrQkFBa0I7QUFBQSxRQUMxQjtBQUVBLGNBQU0sTUFBTSxDQUFDO0FBRWIsY0FBTSxrQkFBa0IsS0FBSyxFQUFFO0FBQy9CLGNBQU0sRUFBQyxNQUFLLElBQUk7QUFDaEIsY0FBTSxrQkFBa0I7QUFFeEIsZUFBTyxLQUFLLE1BQU0sS0FBSztBQUFBLE1BQ3pCO0FBQUEsTUFFQSxRQUFTLE9BQU8sS0FBSyxLQUFLLFNBQVM7QUFDakMsWUFBSSxPQUFPLFVBQVUsWUFBWTtBQUMvQixlQUFLO0FBQ0wsa0JBQVE7QUFBQSxRQUNWO0FBRUEsY0FBTSxFQUFDLG1CQUFtQixnQkFBZSxJQUFJO0FBQzdDLGNBQU0sb0JBQW9CLENBQUNDLE1BQUssU0FBUztBQUN2QyxjQUFJLEtBQUssZUFBZTtBQUN0QixtQkFBTyxLQUFLLElBQUksS0FBSyxhQUFhO0FBQUEsVUFDcEM7QUFFQSxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxZQUFJLE9BQU87QUFDVCxnQkFBTSxrQkFBa0I7QUFBQSxRQUMxQjtBQUVBLGNBQU0sTUFBTSxDQUFDO0FBQ2IsY0FBTSxrQkFBa0IsS0FBSyxFQUFFO0FBQy9CLGNBQU0sRUFBRSxNQUFNLElBQUk7QUFDbEIsZUFBTyxPQUFPLE9BQU8sRUFBQyxtQkFBbUIsZ0JBQWUsQ0FBQztBQUV6RCxlQUFPO0FBQUEsTUFDVDtBQUFBLE1BRUEsR0FBSSxLQUFLLEtBQUssSUFBSTtBQUNoQixjQUFNLENBQUMsSUFBSSxJQUFJLEtBQUssUUFBUSxHQUFHLEVBQUU7QUFFakMsWUFBSSxDQUFDLE1BQU07QUFDVCxpQkFBTyxDQUFDO0FBQUEsUUFDVjtBQUVBLGNBQU0sTUFBTTtBQUFBLFVBQ1YsTUFBTSxLQUFLLGNBQWM7QUFBQSxVQUN6QixRQUFRLEtBQUssZ0JBQWdCO0FBQUEsUUFDL0I7QUFFQSxnQkFBUSxLQUFLLEtBQUssWUFBWSxHQUFHLEtBQUssSUFBSTtBQUUxQyxZQUFJLEtBQUssY0FBYyxHQUFHO0FBQ3hCLGlCQUFPLGVBQWUsS0FBSyxlQUFlO0FBQUEsWUFDeEMsT0FBTztBQUFBLFlBQ1AsY0FBYztBQUFBLFVBQ2hCLENBQUM7QUFBQSxRQUNIO0FBRUEsWUFBSSxLQUFLLE9BQU8sR0FBRztBQUNqQixjQUFJLGFBQWEsS0FBSyxjQUFjO0FBQUEsUUFDdEM7QUFJQSxZQUFJLEtBQUssU0FBUyxHQUFHO0FBQ25CLGNBQUksU0FBUztBQUFBLFFBQ2Y7QUFFQSxZQUFJO0FBQ0osWUFBSTtBQUNGLHFCQUFXLEtBQUssWUFBWTtBQUFBLFFBQzlCLFNBQVMsR0FBRztBQUFBLFFBQ1o7QUFFQSxZQUFJLFlBQVksYUFBYSxZQUFZLGFBQWEsbUJBQW1CO0FBQ3ZFLGNBQUksT0FBTztBQUFBLFFBQ2I7QUFFQSxjQUFNLFFBQVEsS0FBSyxnQkFBZ0I7QUFDbkMsWUFBSSxPQUFPO0FBQ1QsY0FBSSxXQUFXO0FBQUEsUUFDakI7QUFFQSxjQUFNLE9BQU8sS0FBSyxjQUFjO0FBQ2hDLFlBQUksUUFBUSxVQUFVLE1BQU07QUFDMUIsY0FBSSxTQUFTO0FBQUEsUUFDZjtBQUVBLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxVQUFXLE1BQU07QUFDZixjQUFNLFFBQVEsUUFBUSxLQUFLLE1BQU0sRUFBRTtBQUNuQyxZQUFJLENBQUMsT0FBTztBQUNWLGlCQUFPO0FBQUEsUUFDVDtBQUVBLGNBQU0sT0FBTyxNQUFNLENBQUMsTUFBTTtBQUMxQixZQUFJLFFBQVEsTUFBTSxDQUFDO0FBQ25CLGNBQU0sYUFBYSxNQUFNLENBQUM7QUFDMUIsY0FBTSxXQUFXLE1BQU0sQ0FBQztBQUN4QixjQUFNLFdBQVcsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUNoQyxjQUFNLFVBQVUsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUMvQixZQUFJLE9BQU8sTUFBTSxDQUFDO0FBQ2xCLGNBQU0sT0FBTyxNQUFNLENBQUM7QUFDcEIsY0FBTSxNQUFNLE1BQU0sQ0FBQztBQUNuQixjQUFNLFNBQVMsTUFBTSxFQUFFLE1BQU07QUFDN0IsY0FBTSxhQUFhLE1BQU0sRUFBRSxNQUFNO0FBQ2pDLFlBQUk7QUFFSixjQUFNLE1BQU0sQ0FBQztBQUViLFlBQUksTUFBTTtBQUNSLGNBQUksT0FBTyxPQUFPLElBQUk7QUFBQSxRQUN4QjtBQUVBLFlBQUksS0FBSztBQUNQLGNBQUksU0FBUyxPQUFPLEdBQUc7QUFBQSxRQUN6QjtBQUVBLFlBQUksY0FBYyxNQUFNO0FBTXRCLGNBQUksU0FBUztBQUNiLG1CQUFTLElBQUksS0FBSyxTQUFTLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDeEMsZ0JBQUksS0FBSyxPQUFPLENBQUMsTUFBTSxLQUFLO0FBQzFCO0FBQUEsWUFDRixXQUFXLEtBQUssT0FBTyxDQUFDLE1BQU0sT0FBTyxLQUFLLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSztBQUMvRDtBQUNBLGtCQUFJLFdBQVcsTUFBTSxLQUFLLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSztBQUMvQyxzQkFBTSxTQUFTLEtBQUssTUFBTSxHQUFHLElBQUksQ0FBQztBQUNsQyxzQkFBTSxRQUFRLEtBQUssTUFBTSxJQUFJLENBQUM7QUFDOUIsdUJBQU87QUFDUCx5QkFBUyxLQUFLLE1BQU07QUFDcEI7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBRUEsWUFBSSxPQUFPO0FBQ1QsZ0JBQU0sY0FBYyxNQUFNLE1BQU0sUUFBUTtBQUN4QyxjQUFJLGFBQWE7QUFDZixvQkFBUSxZQUFZLENBQUM7QUFDckIscUJBQVMsWUFBWSxDQUFDO0FBQUEsVUFDeEI7QUFBQSxRQUNGO0FBRUEsZ0JBQVEsS0FBSyxNQUFNLEtBQUssSUFBSTtBQUU1QixZQUFJLE1BQU07QUFDUixpQkFBTyxlQUFlLEtBQUssZUFBZTtBQUFBLFlBQ3hDLE9BQU87QUFBQSxZQUNQLGNBQWM7QUFBQSxVQUNoQixDQUFDO0FBQUEsUUFDSDtBQUVBLFlBQUksWUFBWTtBQUNkLGNBQUksYUFBYTtBQUNqQixjQUFJLFdBQVc7QUFDZixjQUFJLGFBQWE7QUFDakIsY0FBSSxXQUFXLFlBQVksU0FBUyxRQUFRLE9BQU8sR0FBRztBQUFBLFFBQ3hEO0FBRUEsWUFBSSxRQUFRO0FBQ1YsY0FBSSxTQUFTO0FBQUEsUUFDZjtBQUVBLFlBQUksT0FBTztBQUNULGNBQUksV0FBVztBQUFBLFFBQ2pCO0FBRUEsWUFBSSxVQUFVLFVBQVUsUUFBUTtBQUM5QixjQUFJLFNBQVM7QUFBQSxRQUNmO0FBRUEsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsYUFBUyxRQUFTLFFBQVEsVUFBVUMsTUFBSztBQUN2QyxVQUFJLFVBQVU7QUFDWixtQkFBVyxTQUFTLFFBQVEsT0FBTyxHQUFHO0FBQ3RDLFlBQUksU0FBUyxXQUFXLEdBQUdBLElBQUcsR0FBRyxHQUFHO0FBQ2xDLHFCQUFXLFNBQVMsTUFBTUEsS0FBSSxTQUFTLENBQUM7QUFBQSxRQUMxQztBQUVBLGVBQU8sT0FBTztBQUFBLE1BQ2hCO0FBQUEsSUFDRjtBQUVBLGFBQVMsc0JBQXNCLGlCQUFpQjtBQUM5QyxVQUFJLGdCQUFnQixXQUFXLEdBQUc7QUFDaEMsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUVBLFlBQU0sV0FBVyxnQkFBZ0IsSUFBSSxTQUFPLG1CQUFtQixHQUFHLENBQUM7QUFFbkUsYUFBTyxJQUFJLE9BQU8sZ0NBQWtDLFNBQVMsS0FBSyxHQUFHLENBQUMseUJBQTBCO0FBQUEsSUFDbEc7QUFFQSxRQUFNLEtBQUssSUFBSTtBQUFBLE1BQ2I7QUFBQSxJQXVCRjtBQUVBLFFBQU0sV0FBVztBQUVqQixJQUFBSCxRQUFPLFVBQVVDO0FBQUE7QUFBQTs7O0FDdlZqQiw0QkFBdUM7OztBQ0F2QyxxQkFBZTtBQUNmLHVCQUFpQjtBQUVqQix3QkFBc0I7QUFLdEIsSUFBTSxpQkFBaUI7QUFFdkIsSUFBTSxvQkFBb0IsQ0FBQyxRQUFRO0FBR25DLElBQU0sc0JBQXNCO0FBSTVCLFNBQVMsc0JBQXNCLFNBQWlCLGdCQUEyQixXQUErQjtBQUN4RyxRQUFNLHNCQUFzQjtBQUM1QixNQUNFLENBQUMsYUFDRCxPQUFPLGVBQWUsU0FBUyxlQUMvQixPQUFPLGVBQWUsV0FBVyxlQUNqQyxDQUFDLG9CQUFvQixLQUFLLE9BQU8sR0FDakM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sRUFBRSxNQUFNLE9BQU8sSUFBSTtBQUN6QixRQUFNLFFBQVEsVUFBVSxtQkFBbUIsTUFBTSxNQUFNO0FBQ3ZELE1BQUksQ0FBQyxPQUFPLE1BQU07QUFDaEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPLFFBQVEsUUFBUSxjQUFjLE1BQU0sSUFBSTtBQUNqRDtBQUtBLFNBQVMsYUFBYSxXQUFzQixXQUFzQixvQkFBd0M7QUFDeEcsTUFBSSxDQUFDLFVBQVUsUUFBUSxDQUFDLFVBQVUsUUFBUSxDQUFDLFVBQVUsUUFBUTtBQUMzRCxXQUFPO0FBQUEsRUFDVDtBQUVBLFFBQU0sVUFBVSxVQUFVLG1CQUFtQixVQUFVLE1BQU0sVUFBVSxNQUFNO0FBQzdFLE1BQUksQ0FBQyxTQUFTO0FBQ1osV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPO0FBQUEsSUFDTCxLQUFLLFVBQVU7QUFBQSxJQUNmLE1BQU0saUJBQUFHLFFBQUssUUFBUSxpQkFBQUEsUUFBSyxRQUFRLFVBQVUsSUFBSSxHQUFHLFFBQVEsVUFBVSxFQUFFO0FBQUEsSUFDckUsYUFBYSxzQkFBc0IsUUFBUSxTQUFTLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxJQUFJO0FBQUEsSUFDakcsTUFBTSxRQUFRLFVBQVU7QUFBQSxJQUN4QixRQUFRLFFBQVEsVUFBVTtBQUFBLElBQzFCLFVBQVUsVUFBVTtBQUFBLEVBQ3RCO0FBQ0Y7QUFFQSxTQUFTLHNCQUFzQixNQUE2QjtBQUMxRCxRQUFNLGdCQUFnQixHQUFHLElBQUk7QUFDN0IsTUFBSSxDQUFDLGVBQUFDLFFBQUcsV0FBVyxhQUFhLEdBQUc7QUFDakMsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPLGVBQUFBLFFBQUcsYUFBYSxhQUFhLEVBQUUsU0FBUyxNQUFNO0FBQ3ZEO0FBRUEsU0FBUyxvQkFBb0IsTUFBNkI7QUFDeEQsTUFBSSxDQUFDLGVBQUFBLFFBQUcsV0FBVyxJQUFJLEdBQUc7QUFDeEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLGVBQWUsZUFBQUEsUUFBRyxhQUFhLElBQUksRUFBRSxTQUFTLE1BQU07QUFDMUQsTUFBSSxDQUFDLGVBQWUsS0FBSyxZQUFZLEdBQUc7QUFDdEMsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLGdCQUFnQixhQUFhLE1BQU0sYUFBYSxZQUFZLEdBQUcsSUFBSSxDQUFDO0FBQzFFLFFBQU0sZ0JBQWdCLE9BQU8sS0FBSyxlQUFlLFFBQVEsRUFBRSxTQUFTLE1BQU07QUFDMUUsU0FBTztBQUNUO0FBR0EsU0FBUyxnQkFBZ0IsTUFBZ0M7QUFDdkQsTUFBSSxrQkFBa0IsS0FBSyxDQUFDLGNBQWMsVUFBVSxLQUFLLElBQUksQ0FBQyxHQUFHO0FBQy9ELFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTSxtQkFBbUIsb0JBQW9CLElBQUksS0FBSyxzQkFBc0IsSUFBSTtBQUVoRixNQUFJLENBQUMsa0JBQWtCO0FBQ3JCLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTSxTQUFTLEtBQUssTUFBTSxnQkFBZ0I7QUFFMUMsUUFBTSxZQUFZLElBQUksa0JBQUFDLFFBQVU7QUFDaEMsWUFBVSxVQUFVLE1BQU07QUFDMUIsU0FBTztBQUNUO0FBR08sU0FBUyxxQkFDZCxTQUNBLE9BQ0EscUJBQ3dGO0FBQ3hGLE1BQUksQ0FBQyxPQUFPO0FBQ1YsV0FBTyxFQUFFLFNBQVMsT0FBTyxvQkFBb0I7QUFBQSxFQUMvQztBQUNBLFFBQU0sYUFBYSxvQkFBSSxJQUF1QjtBQUM5QyxNQUFJLGlCQUFpQjtBQUVyQixRQUFNLGNBQWMsTUFBTSxJQUFJLENBQUMsY0FBYztBQUMzQyxRQUFJLGtCQUFrQix1QkFBdUIsQ0FBQyxVQUFVLE1BQU07QUFDNUQsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJO0FBQ0YsWUFBTSxZQUFZLFdBQVcsSUFBSSxVQUFVLElBQUksS0FBSyxnQkFBZ0IsVUFBVSxJQUFJO0FBQ2xGLFVBQUksQ0FBQyxXQUFXO0FBQ2QsZUFBTztBQUFBLE1BQ1Q7QUFDQSxpQkFBVyxJQUFJLFVBQVUsTUFBTSxTQUFTO0FBQ3hDLGFBQU8sYUFBYSxXQUFXLFdBQVcsbUJBQW1CLENBQUM7QUFBQSxJQUNoRSxRQUFRO0FBQUEsSUFFUixVQUFFO0FBQ0Esd0JBQWtCO0FBQUEsSUFDcEI7QUFDQSxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBRUQsbUJBQWlCO0FBRWpCLFFBQU0sdUJBQXVCLHFCQUFxQixJQUFJLENBQUMsY0FBYztBQUNuRSxRQUFJLGtCQUFrQix1QkFBdUIsQ0FBQyxVQUFVLE1BQU07QUFDNUQsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJO0FBQ0YsWUFBTSxZQUFZLFdBQVcsSUFBSSxVQUFVLElBQUksS0FBSyxnQkFBZ0IsVUFBVSxJQUFJO0FBQ2xGLFVBQUksQ0FBQyxXQUFXO0FBQ2QsZUFBTztBQUFBLE1BQ1Q7QUFDQSxpQkFBVyxJQUFJLFVBQVUsTUFBTSxTQUFTO0FBQ3hDLGFBQU8sYUFBYSxXQUFXLFdBQVcsbUJBQW1CLENBQUM7QUFBQSxJQUNoRSxRQUFRO0FBQUEsSUFFUixVQUFFO0FBQ0Esd0JBQWtCO0FBQUEsSUFDcEI7QUFDQSxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBRUQsUUFBTSxpQkFBaUIsTUFBTSxDQUFDO0FBQzlCLE1BQUksQ0FBQyxrQkFBa0IsT0FBTyxlQUFlLFNBQVMsZUFBZSxPQUFPLFlBQVksYUFBYTtBQUNuRyxXQUFPLEVBQUUsU0FBUyxPQUFPLGFBQWEscUJBQXFCLHFCQUFxQjtBQUFBLEVBQ2xGO0FBRUEsU0FBTztBQUFBLElBQ0wsU0FBUyxzQkFBc0IsU0FBUyxnQkFBZ0IsV0FBVyxJQUFJLGVBQWUsSUFBSSxDQUFDO0FBQUEsSUFDM0YsT0FBTztBQUFBLElBQ1AscUJBQXFCO0FBQUEsRUFDdkI7QUFDRjs7O0FDaktBLHlCQUF1QjtBQUd2QixJQUFNLGtCQUFrQixDQUFDLHFCQUFxQixzQ0FBc0M7QUFFcEYsSUFBTSxnQkFBZ0I7QUFHdEIsSUFBTSxhQUFhLElBQUksbUJBQUFDLFFBQVcsRUFBRSxXQUFXLG1CQUFBQSxRQUFXLGNBQWMsRUFBRSxDQUFDO0FBR3BFLFNBQVMsZ0JBQWdCLE9BQXlDO0FBQ3ZFLE1BQUksQ0FBQyxPQUFPO0FBQ1YsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNLGFBQWEsTUFDaEIsTUFBTSxJQUFJLEVBQ1YsTUFBTSxHQUFHLGFBQWEsRUFDdEIsSUFBSSxDQUFDLFNBQVM7QUFDYixVQUFNLGFBQWEsV0FBVyxVQUFVLElBQUk7QUFDNUMsV0FBTztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsTUFBTSxZQUFZO0FBQUEsTUFDbEIsTUFBTSxZQUFZO0FBQUEsTUFDbEIsUUFBUSxZQUFZO0FBQUEsTUFDcEIsVUFBVSxZQUFZO0FBQUEsSUFDeEI7QUFBQSxFQUNGLENBQUM7QUFFSCxTQUFPLFdBQVcsT0FBTyxDQUFDLGNBQWM7QUFDdEMsV0FBTyxDQUFDLGdCQUFnQixLQUFLLENBQUMsY0FBYztBQUMxQyxhQUFPLFVBQVUsS0FBSyxVQUFVLFFBQVEsRUFBRTtBQUFBLElBQzVDLENBQUM7QUFBQSxFQUNILENBQUM7QUFDSDs7O0FGL0JBLGtDQUFZO0FBQUEsRUFDVjtBQUFBLElBQ0Usa0NBQVk7QUFBQSxJQUNaLGdCQUFnQixrQ0FBWSxLQUFLO0FBQUEsSUFDakMsZ0JBQWdCLGtDQUFZLG1CQUFtQjtBQUFBLEVBQ2pEO0FBQ0Y7IiwKICAibmFtZXMiOiBbImV4cG9ydHMiLCAibW9kdWxlIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgIlN0YWNrVXRpbHMiLCAib2JqIiwgImN3ZCIsICJwYXRoIiwgImZzIiwgIlNvdXJjZU1hcCIsICJTdGFja1V0aWxzIl0KfQo=
